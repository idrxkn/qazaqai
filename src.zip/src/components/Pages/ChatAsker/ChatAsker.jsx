import { useState, useEffect, useRef } from "react";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import "./ChatAsker.css"
import logo from "../../../assets/logo.svg";
import teacherIcon from "../../../assets/teachersx.png";
import { useAuth } from "../../../context/AuthContext";
import { Link } from "react-router-dom";
import axios from "axios";
import { useTranslation } from "react-i18next";
import Header from "../../Header/Header";

const ChatAsker = () => {
  return (
    <div>
      <h3 className="chat-h3">This is chat asker</h3>
    </div>
  );
};

export default ChatAsker;
