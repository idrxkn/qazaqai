import React, { useState, useEffect } from "react";
import teacher from "../../assets/kundz.png";
import { useNavigate } from "react-router-dom";
import "./MyProfile.css";
import { useAuth } from "../../context/AuthContext";
import { fetchUserData } from "../../api";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import Footer from "../Footer/Footer";
import QRCode from "qrcode.react";
import { motion, AnimatePresence } from "framer-motion";

const MyProfile = () => {
  const navigate = useNavigate();
  const { setIsAuthenticated, userRole, setUserRole } = useAuth(); // Access and set role from context
  const [userData, setUserData] = useState({
    firstName: "",
    lastName: "",
    username: "",
    email: "",
    phoneNumber: "",
    referral: null,
    studentCount: null,
    teacherName: "",
    students: [],
  });
  const [showQRCode, setShowQRCode] = useState(false);
  const [editField, setEditField] = useState(null);
  const [formData, setFormData] = useState({});

  const handleLogout = () => {
    localStorage.removeItem("token");
    setIsAuthenticated(false);
    navigate("/");
  };

  const handleToggleQRCode = () => {
    setShowQRCode(!showQRCode);
  };

  const handleEditField = (field) => {
    setFormData({ [field]: userData[field] });
    setEditField(field);
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({ [name]: value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const token = localStorage.getItem("token");
      const updatedData = { [editField]: formData[editField] };

      const response = await fetch("http://localhost:10000/api/profile", {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify(updatedData),
      });

      if (response.ok) {
        setUserData((prevState) => ({
          ...prevState,
          ...updatedData,
        }));
        setEditField(null);
      } else {
        console.error("Профильді жаңартуда қате кетті");
      }
    } catch (error) {
      console.error("Қате:", error);
    }
  };

  useEffect(() => {
    const getUserData = async () => {
      try {
        const data = await fetchUserData();
        console.log(data.StudentCount);

        setUserData({
          firstName: data.firstName || "Дерек жоқ",
          lastName: data.lastName || "Дерек жоқ",
          username: data.UserName || "Дерек жоқ",
          email: data.Email || "Дерек жоқ",
          phoneNumber: data.PhoneNumber || "Дерек жоқ",
          referral: data.ReferralCode || "Дерек жоқ",
          studentCount: data.StudentCount || "0",
          role: data.Role || "Дерек жоқ",
          teacherName: data.Teacher ? data.Teacher.TeacherName : "Дерек жоқ",
          students: data.Students || [],
          testResults: data.TestResults || [],
        });
        setUserRole(data.Role);
      } catch (error) {
        console.error("Error fetching profile data:", error);
      }
    };
    getUserData();
  }, [setUserRole]);

  // Convert role to Kazakh if needed:
  const roleText =
    userData.role !== "Teacher"
      ? "Оқушы"
      : userData.role === "Teacher"
      ? "Мұғалім"
      : userData.role;

  return (
    <>
      <div className="profile-page">
        <div className="profile-wrap">
          <div className="profile-header">
            <div className="profile-pic">
              <FontAwesomeIcon icon="fa-solid fa-graduation-cap" />
            </div>

            <div className="profile-inf">
              <h1>{userData.username}</h1>

              <p className="roles">Рөлі: {roleText}</p>
            </div>
          </div>
          <div className="profile-details">
            {editField === "username" ? (
              <form onSubmit={handleSubmit}>
                <div className="form-group">
                  <label htmlFor="username">Пайдаланушы аты</label>

                  <input
                    type="text"
                    id="username"
                    name="username"
                    value={formData.username}
                    onChange={handleChange}
                    className="usr-form"
                  />
                </div>
                <button type="submit" className="sv-btn">
                  Сақтау
                </button>
                <button
                  type="button"
                  onClick={() => setEditField(null)}
                  className="cn-btn"
                >
                  Бас тарту
                </button>
              </form>
            ) : (
              <p>
                Пайдаланушы аты: {userData.username}{" "}
                <button
                  onClick={() => handleEditField("username")}
                  className="edit-btn"
                >
                  Өңдеу
                </button>
              </p>
            )}
            {editField === "email" ? (
              <form onSubmit={handleSubmit}>
                <div className="form-group">
                  <label htmlFor="email">Электрондық пошта</label>
                  <input
                    type="email"
                    id="email"
                    name="email"
                    value={formData.email}
                    onChange={handleChange}
                    className="usr-form"
                  />
                </div>
                <button type="submit" className="sv-btn">
                  Сақтау
                </button>
                <button
                  type="button"
                  onClick={() => setEditField(null)}
                  className="cn-btn"
                >
                  Бас тарту
                </button>
              </form>
            ) : (
              <p>
                Электрондық пошта: {userData.email}{" "}
                <button
                  onClick={() => handleEditField("email")}
                  className="edit-btn"
                >
                  Өңдеу
                </button>
              </p>
            )}
            {editField === "phoneNumber" ? (
              <form onSubmit={handleSubmit}>
                <div className="form-group">
                  <label htmlFor="phoneNumber">Телефон нөмірі</label>
                  <input
                    type="text"
                    id="phoneNumber"
                    name="phoneNumber"
                    value={formData.phoneNumber}
                    onChange={handleChange}
                    className="usr-form"
                  />
                </div>
                <button type="submit" className="sv-btn">
                  Сақтау
                </button>
                <button
                  type="button"
                  onClick={() => setEditField(null)}
                  className="cn-btn"
                >
                  Бас тарту
                </button>
              </form>
            ) : (
              <p>
                Телефон нөмірі: {userData.phoneNumber}{" "}
                <button
                  onClick={() => handleEditField("phoneNumber")}
                  className="edit-btn"
                >
                  Өңдеу
                </button>
              </p>
            )}
            {userData.role !== "Teacher" ? (
              <p>
                <strong>Мұғалімнің аты:</strong> {userData.teacherName}
              </p>
            ) : (
              <>
                {userData.studentCount !== null && (
                  <p>
                    <strong>Оқушылар саны:</strong> {userData.studentCount}
                  </p>
                )}
                {userData.referral !== null && (
                  <>
                    <div className="referral-wrap">
                      <div className="referral">
                        <p>
                          <strong>Реферал коды:</strong> {userData.referral}
                        </p>
                        <button
                          onClick={handleToggleQRCode}
                          className="qr-button"
                        >
                          {showQRCode ? "QR-ды жасыру" : "Рефералға QR жасау"}
                        </button>
                      </div>
                      <AnimatePresence>
                        {showQRCode && (
                          <motion.div
                            initial={{ opacity: 0, y: -10 }}
                            animate={{ opacity: 1, y: 0 }}
                            exit={{ opacity: 0, y: 10 }}
                            transition={{ duration: 0.5 }}
                            className="qr"
                          >
                            <QRCode value={userData.referral} />
                          </motion.div>
                        )}
                      </AnimatePresence>
                    </div>
                  </>
                )}
                {userData.students.length > 0 && (
                  <div>
                    <strong>Оқушылар:</strong>
                    <ol>
                      {userData.students.map((student) => (
                        <li key={student.StudentId}>{student.StudentName}</li>
                      ))}
                    </ol>
                  </div>
                )}
              </>
            )}
            {userData.testResults && userData.testResults.length > 0 ? (
              <div className="test-results-section">
                <h2>Тест нәтижелері</h2>
                <ul>
                  {userData.testResults.map((test, index) => (
                    <li key={index}>
                      <strong>📋 {test.testName}</strong>
                      <span>Тақырыбы: {test.testTopic}</span>
                      <span>Сұрақ саны: {test.totalQuestions}</span>
                      <span>✅ Дұрыс жауаптар: {test.rightAnswersCount}</span>
                      <span>❌ Қате жауаптар: {test.wrongAnswersCount}</span>
                      <span>📚 Тақырыптар: {test.subTopics.join(", ")}</span>
                    </li>
                  ))}
                </ul>
              </div>
            ) : (
              <p>Тест нәтижелері жоқ</p>
            )}

            <button className="logout" onClick={handleLogout}>
              Шығу
            </button>
          </div>
        </div>
      </div>
      <Footer />
    </>
  );
};

export default MyProfile;
